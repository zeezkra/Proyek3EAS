<?php

namespace App\Http\Controllers;

use App\Models\barang;
use Illuminate\Http\Request;

class barangController extends Controller
{
    public function index()
    {
        $barangs = barang::all();
        return view('barang.index', compact('barangs'));
    }

    public function create()
    {
        return view('barang.create');
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'KodeBarang' => 'required|integer',
            'NamaBarang' => 'required|string|max:50',
            'Satuan' => 'required|integer',
            'HargaSatuan' => 'required|string|max:100',
            'Stok' => 'required|integer',
        ]);

        Barang::create($validatedData);

        return redirect()->route('barang.index')->with('success', 'Barang created successfully.');
    }

    public function show($id)
    {
        $barang = Barang::findOrFail($id);
        return view('barang.show', compact('barang'));
    }

    public function edit($id)
    {
        $barang = Barang::findOrFail($id);
        return view('barang.edit', compact('barang'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'KodeBarang' => 'required|integer',
            'NamaBarang' => 'required|string|max:50',
            'Satuan' => 'required|integer',
            'HargaSatuan' => 'required|string|max:100',
            'Stok' => 'required|integer',
        ]);

        $barang = Barang::findOrFail($id);
        $barang->update($request->all());

        return redirect()->route('barang.index')->with('success', 'Barang successfully updated!');
    }

    public function destroy($id)
    {
        $barang = barang::findOrFail($id);
        $barang->delete();

        return redirect()->route('barang.index')->with('success', 'Barang successfully deleted!');
    }
}

