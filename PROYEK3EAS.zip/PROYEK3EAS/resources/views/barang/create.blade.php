<!-- resources/views/barang/create.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container mt-5">
        <form action="{{ route('barang.store') }}" method="post">
            @csrf
            <div class="mb-3">
                <label for="kodeBarang" class="form-label">Kode Barang</label>
                <input type="text" class="form-control" id="kodeBarang" name="kodeBarang" placeholder="Masukkan Kode Barang">
            </div>
            <div class="mb-3">
                <label for="namaBarang" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="namaBarang" name="namaBarang" placeholder="Masukkan Nama Barang">
            </div>
            <div class="mb-3">
                <label for="satuan" class="form-label">Satuan</label>
                <input type="text" class="form-control" id="satuan" name="satuan" placeholder="Masukkan Satuan">
            </div>
            <div class="mb-3">
                <label for="hargaSatuan" class="form-label">Harga Satuan</label>
                <input type="number" class="form-control" id="hargaSatuan" name="hargaSatuan" placeholder="Masukkan Harga Satuan">
            </div>
            <div class="mb-3">
                <label for="stok" class="form-label">Stok</label>
                <input type="number" class="form-control" id="stok" name="stok" placeholder="Masukkan Stok">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
@endsection
