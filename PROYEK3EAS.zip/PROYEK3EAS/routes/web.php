<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\barangController;

Route::prefix('barang')->group(function () {
    Route::get('/', [barangController::class, 'index'])->name('barang.index');
    Route::get('/getData', [barangController::class, 'barangData'])->name('barang.data');
    Route::get('/create', [barangController::class, 'create'])->name('barang.create');
    Route::post('/store', [barangController::class, 'store'])->name('barang.store');
    Route::get('/{id}', [barangController::class, 'show'])->name('barang.show');
    Route::get('/{id}/edit', [barangController::class, 'edit'])->name('barang.edit');
    Route::put('/{id}', [barangController::class, 'update'])->name('barang.update');
    Route::delete('/{id}', [barangController::class, 'destroy'])->name('barang.destroy');
});